package com.training.cb_topicService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CbTopicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
