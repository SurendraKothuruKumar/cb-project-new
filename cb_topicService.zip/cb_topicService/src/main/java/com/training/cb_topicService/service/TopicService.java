package com.training.cb_topicService.service;

import java.util.List;

import com.training.cb_topicService.model.Topic;

public interface TopicService {
	public List<Topic> findAll();
	public Topic findById(int id);
	public List<Topic> findByTrainingId(int trainingId);
	public Topic save(Topic training); 

}
