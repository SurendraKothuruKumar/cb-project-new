package com.training.cb_topicService.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

//import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
//import lombok.NoArgsConstructor;

@Entity

@Builder
@Data
public class Topic {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int trainingId;
	private String topics;
	public Topic(int id, int trainingId, String topics) {
		super();
		this.id = id;
		this.trainingId = trainingId;
		this.topics = topics;
	}
	public Topic() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	public String getTopics() {
		return topics;
	}
	public void setTopics(String topics) {
		this.topics = topics;
	}
	@Override
	public String toString() {
		return "Topic [id=" + id + ", trainingId=" + trainingId + ", topics=" + topics + "]";
	}
	
	
}
