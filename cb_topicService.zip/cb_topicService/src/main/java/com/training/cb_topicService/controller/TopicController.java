package com.training.cb_topicService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.cb_topicService.model.Topic;
import com.training.cb_topicService.service.TopicService;


@RestController
public class TopicController {
	
	@Autowired
	TopicService topicService;
	
	@GetMapping("/topics")
	public ResponseEntity<List> findAll() {
		return new ResponseEntity<List>(topicService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/topic")
	public ResponseEntity<Topic> findById(@RequestParam int id) {
		return new ResponseEntity<Topic>(topicService.findById(id),HttpStatus.OK);
	}
	
	@GetMapping("/topicsByTrainingId")
	public ResponseEntity<List> findByTrainingId(@RequestParam int trainingId) {
		return new ResponseEntity<List>(topicService.findByTrainingId(trainingId),HttpStatus.OK);
	}
	
	@PostMapping("/topic")
	public ResponseEntity<Topic> create(@RequestBody Topic topic) {
		return new ResponseEntity<Topic>(topicService.save(topic),HttpStatus.CREATED);
	}

}
