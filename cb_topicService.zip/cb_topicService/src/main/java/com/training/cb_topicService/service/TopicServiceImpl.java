package com.training.cb_topicService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.cb_topicService.model.Topic;
import com.training.cb_topicService.repository.TopicRepository;

@Service
public class TopicServiceImpl implements TopicService {

	@Autowired
	TopicRepository topicRepo;
	
	@Override
	public List<Topic> findAll() {
		return topicRepo.findAll();
	}

	@Override
	public Topic findById(int id) {
		return topicRepo.findById(id).get();
	}

	@Override
	public List<Topic> findByTrainingId(int trainingId) {
		return topicRepo.findAllByTrainingId(trainingId);
	}

	@Override
	public Topic save(Topic training) {
		return topicRepo.save(training);
	}

}
